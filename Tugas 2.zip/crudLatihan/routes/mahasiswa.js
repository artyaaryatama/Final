var express = require('express');
const Mahasiswa = require('../model/mahasiswaModel');
var mahasiswa = require('../model/mahasiswaModel')
var router = express.Router();
var db = require('../db')

router.get('/', function(req, res, next) {
    res.render('index', {title : 'homePage'})
});

router.get('/listmahasiswa', function(req, res, next) {
    mahasiswa.selectAllMahasiswa((err, result) => {
        if (err) {
            console.log(err)
        } else {
            res.render('listmahasiswa', {title : 'list Mahasiswa', data : result})
        }
    })
})
router.get('/listmahasiswa/:id/updatemahasiswa', function(req, res, next) {
    Mahasiswa.selectMahasiswa(req.params.id, (err, result) => {
        let data = result[0];
        if (err) {
            console.log(err)
        } else {
            console.log(result)
            res.render('updatemahasiswa', {title : 'Update data mahasiswa', data})

        }
    })
})

router.get('/addmahasiswa', function(req, res, next) {
    // res.send('ini bagian add')
    res.render('addmahasiswa', {title : 'Formulir Mahasiswa'})
})


router.post('/addmahasiswa', (req, res) => {
    console.log(`\n Data berhasil disimpan\n`)
    console.log(req.body)
    Mahasiswa.insertIntoMahasiswa(req.body, (err, result) => {
        if (err) {
            console.log(err)
        } else {
            res.redirect('/listmahasiswa')
            console.log(result)
        }
    })
    
})

router.post('/listmahasiswa/:id/updatemahasiswa', (req, res) => {
    Mahasiswa.updateMahasiswa(req.body.nama, req.body.nim, req.params.id, (err, result) => {
        if (err) {
            console.log(err)
        } else {
            console.log('Berhasil di update')
            console.log(result)
            res.redirect('/listmahasiswa')
        }
    })
})

router.get('/hapus/:id',(req, res) => {
    Mahasiswa.deleteMahasiswa(req.params.id, (err, result) => {
        res.redirect('/listmahasiswa')
    })
} )
module.exports = router;
