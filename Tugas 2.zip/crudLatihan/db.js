var mysql = require('mysql')

var connection = mysql.createConnection({
  host : '127.0.0.2',
  user : 'root',
  password : '',
  database : 'crudLatihan'  
})

connection.connect(err => {
    if(err) throw err;
})

module.exports = connection