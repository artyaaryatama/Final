var sql = require('../db')

var Mahasiswa = () => {}

Mahasiswa.selectAllMahasiswa = (callback) => {
    sql.query('select * from mahasiswa', (err, res) => {
        if(err) {
            console.log(err)
            callback(err, null)
        } else {
            callback(null, res)
        }
    })
}

Mahasiswa.selectMahasiswa = (id, callback) => {
    sql.query('select * from mahasiswa where id = ?', id, (err, res) => {
        if(err) {
            console.log(err)
            callback(err, null)
        } else {
            callback(null, res)
        }
    })
}

Mahasiswa.updateMahasiswa = (nama, nim, id, callback) => {
    sql.query('update mahasiswa set nama = ?, nim = ? where id = ?', [nama, nim, id], (err, res) => {
        if(err) {
            console.log(err)
            callback(err, null)
        } else {
            callback(null, res)
        }
    })
}

Mahasiswa.insertIntoMahasiswa = (newData, callback) => {
    sql.query('insert into mahasiswa set ?', newData, (err, res) => {
        if(err) {
            console.log(err)
            callback(err, null)
        } else {
            callback(null, res)
        }
    })
}

Mahasiswa.deleteMahasiswa = (id, callback) => {
    sql.query('delete from mahasiswa where id = ?', id, (err, res) => {
        if(err) {
            console.log(err)
            callback(err, null)
        } else {
            callback(null, res)
        }
    })
}

module.exports = Mahasiswa